package org.pltw.examples.animalapp;

/**
 * Created by liu57142 on 2/1/2018.
 */

public class Fox extends Animal implements Fun{
    public Fox(){}
    public String say(){ return "Joff-tchoff-tchoffo-tchoffo-tchoff"; }
    public String say2(){ return "Fox"; }
    public String play() { return "The fox chases mice and digs holes!"; }
}
