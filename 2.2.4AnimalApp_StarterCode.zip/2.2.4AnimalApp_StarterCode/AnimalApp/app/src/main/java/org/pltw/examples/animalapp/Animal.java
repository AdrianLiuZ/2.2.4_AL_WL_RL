package org.pltw.examples.animalapp;

/**
 * Created by liu57142 on 1/30/2018.
 */

public abstract class Animal {
    abstract String say();
    abstract String say2();
}
