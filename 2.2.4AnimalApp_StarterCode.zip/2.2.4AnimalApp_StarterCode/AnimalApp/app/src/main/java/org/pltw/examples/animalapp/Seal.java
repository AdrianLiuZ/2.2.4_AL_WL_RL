package org.pltw.examples.animalapp;

/**
 * Created by liu57142 on 1/30/2018.
 */

public class Seal extends Animal implements Fun {
    public Seal(){

    }
    public String say() {
        return "seal goes ow ow ow";
    }
    public String say2() {
        return "Seal";
    }

    public String play() {
        return "the seal bounces the ball off its nose";
    }
}
