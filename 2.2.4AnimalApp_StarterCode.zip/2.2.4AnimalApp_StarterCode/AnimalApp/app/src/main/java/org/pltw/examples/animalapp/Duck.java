package org.pltw.examples.animalapp;

/**
 * Created by liu57142 on 1/30/2018.
 */

public class Duck extends Animal {
    public Duck() {

    }
    public String say() {
        return "Duck says Quack";
    }
    public String say2() {
        return "Duck";
    }
}
