package org.pltw.examples.animalapp;


/**
 * Created by liu57142 on 1/30/2018.
 */

public class Fish extends Animal {
    public Fish(){

    }
    public String say() {
        return "Fish goes Blub";
    }
    public String say2() {
        return "Fish";
    }
}
