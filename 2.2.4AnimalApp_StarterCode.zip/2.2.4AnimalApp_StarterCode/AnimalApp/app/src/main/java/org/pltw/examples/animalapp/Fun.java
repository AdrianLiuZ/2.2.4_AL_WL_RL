package org.pltw.examples.animalapp;

/**
 * Created by liu57142 on 1/30/2018.
 */

public interface Fun {
    public String play();
}
